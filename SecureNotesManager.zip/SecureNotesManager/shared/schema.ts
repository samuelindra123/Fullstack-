import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";

import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  phoneNumber: text("phone_number").unique(),
  fullName: text("full_name"),
  channelUsername: text("channel_username").unique(),
  dateOfBirth: date("date_of_birth"),
  gender: text("gender"),
  interests: text("interests").array(),
  appRating: integer("app_rating"),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
  isPhoneVerified: boolean("is_phone_verified").default(false).notNull(),
  isProfileComplete: boolean("is_profile_complete").default(false).notNull(),
  registrationStep: integer("registration_step").default(1).notNull(),
  profilePicture: text("profile_picture"),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  mediaUrl: text("media_url"),
  mediaType: text("media_type"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => posts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => posts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const emailOtpVerifications = pgTable("email_otp_verifications", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  otp: text("otp").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
});

export const phoneOtpVerifications = pgTable("phone_otp_verifications", {
  id: serial("id").primaryKey(),
  phoneNumber: text("phone_number").notNull(),
  otp: text("otp").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
});

export const registrationSteps = pgTable("registration_steps", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number").unique(),
  username: text("username").unique(),
  password: text("password"),
  emailVerified: boolean("email_verified").default(false).notNull(),
  phoneVerified: boolean("phone_verified").default(false).notNull(),
  step1Complete: boolean("step1_complete").default(false).notNull(),
  step2Complete: boolean("step2_complete").default(false).notNull(),
  step3Complete: boolean("step3_complete").default(false).notNull(),
  step4Complete: boolean("step4_complete").default(false).notNull(),
  
  // Step 1 data
  profilePicture: text("profile_picture"),
  channelUsername: text("channel_username"),
  
  // Step 2 data
  dateOfBirth: date("date_of_birth"),
  gender: text("gender"),
  
  // Step 3 data
  interests: text("interests").array(),
  
  // Step 4 data
  appRating: integer("app_rating"),
  feedback: text("feedback"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Schemas
export const insertUserSchema = createInsertSchema(users, {
  id: undefined,
  createdAt: undefined,
}).extend({
  isVerified: z.boolean().optional().default(false),
});

export const insertPostSchema = createInsertSchema(posts, {
  id: undefined,
  createdAt: undefined,
});

export const insertCommentSchema = createInsertSchema(comments, {
  id: undefined,
  createdAt: undefined,
});

export const insertLikeSchema = createInsertSchema(likes, {
  id: undefined,
  createdAt: undefined,
});

export const insertEmailOtpVerificationSchema = createInsertSchema(emailOtpVerifications, {
  id: undefined,
  createdAt: undefined,
  isVerified: undefined,
});

export const insertPhoneOtpVerificationSchema = createInsertSchema(phoneOtpVerifications, {
  id: undefined,
  createdAt: undefined,
  isVerified: undefined,
});

export const insertRegistrationStepsSchema = createInsertSchema(registrationSteps, {
  id: undefined,
  createdAt: undefined,
  updatedAt: undefined,
});

export const loginSchema = z.object({
  username: z.string().min(1, { message: "Username is required" }),
  password: z.string().min(1, { message: "Password is required" }),
});

export const registerSchema = insertUserSchema.extend({
  phoneNumber: z.string().min(10, { message: "Please enter a valid phone number" }),
  password: z.string().min(8, { message: "Password must be at least 8 characters" })
    .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter" })
    .regex(/[0-9]/, { message: "Password must contain at least one number" })
    .regex(/[^a-zA-Z0-9]/, { message: "Password must contain at least one special character" }),
  confirmPassword: z.string(),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "You must accept the terms to continue",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Email Verification Schemas
export const emailVerificationSchema = z.object({
  otp: z.string().length(6, { message: "OTP must be 6 digits" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
});

// Phone Verification Schemas
export const phoneVerificationSchema = z.object({
  otp: z.string().length(6, { message: "OTP must be 6 digits" }),
  phoneNumber: z.string().min(10, { message: "Please enter a valid phone number" }),
});

// Registration Step Schemas
export const registrationStep1Schema = z.object({
  profilePicture: z.string().optional(),
  channelUsername: z.string().min(3, { message: "Channel username must be at least 3 characters" }),
});

export const registrationStep2Schema = z.object({
  dateOfBirth: z.union([
    z.string().refine(value => {
      const date = new Date(value);
      return !isNaN(date.getTime());
    }, { message: "Please enter a valid date" }),
    z.date()
  ]),
  gender: z.enum(["male", "female", "other", "prefer_not_to_say"]),
});

export const registrationStep3Schema = z.object({
  interests: z.array(z.string()).min(1, { message: "Please select at least one interest" }),
});

export const registrationStep4Schema = z.object({
  appRating: z.number().min(1).max(5),
  feedback: z.string().optional(),
});

export const initialRegistrationSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  phoneNumber: z.string().min(10, { message: "Please enter a valid phone number" }),
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  password: z.string().min(8, { message: "Password must be at least 8 characters" })
    .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter" })
    .regex(/[0-9]/, { message: "Password must contain at least one number" })
    .regex(/[^a-zA-Z0-9]/, { message: "Password must contain at least one special character" }),
  confirmPassword: z.string(),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "You must accept the terms to continue",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const forgotPasswordSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type InsertLike = z.infer<typeof insertLikeSchema>;
export type InsertEmailOtpVerification = z.infer<typeof insertEmailOtpVerificationSchema>;
export type InsertPhoneOtpVerification = z.infer<typeof insertPhoneOtpVerificationSchema>;
export type InsertRegistrationSteps = z.infer<typeof insertRegistrationStepsSchema>;

export type User = typeof users.$inferSelect;
export type Post = typeof posts.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Like = typeof likes.$inferSelect;
export type EmailOtpVerification = typeof emailOtpVerifications.$inferSelect;
export type PhoneOtpVerification = typeof phoneOtpVerifications.$inferSelect;
export type RegistrationStep = typeof registrationSteps.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;
export type EmailVerificationData = z.infer<typeof emailVerificationSchema>;
export type PhoneVerificationData = z.infer<typeof phoneVerificationSchema>;
export type ForgotPasswordData = z.infer<typeof forgotPasswordSchema>;
export type RegistrationStep1Data = z.infer<typeof registrationStep1Schema>;
export type RegistrationStep2Data = z.infer<typeof registrationStep2Schema>;
export type RegistrationStep3Data = z.infer<typeof registrationStep3Schema>;
export type RegistrationStep4Data = z.infer<typeof registrationStep4Schema>;
export type InitialRegistrationData = z.infer<typeof initialRegistrationSchema>;

// Complete Registration Schema
export const completeRegistrationSchema = z.object({
  // Initial registration data
  email: z.string().email({ message: "Please enter a valid email address" }),
  phoneNumber: z.string().min(10, { message: "Please enter a valid phone number" }),
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  password: z.string(),
  
  // Step 1 data
  profilePicture: z.string().optional(),
  channelUsername: z.string().min(3, { message: "Channel username must be at least 3 characters" }),
  
  // Step 2 data
  dateOfBirth: z.union([
    z.string().refine(value => {
      const date = new Date(value);
      return !isNaN(date.getTime());
    }, { message: "Please enter a valid date" }),
    z.date()
  ]),
  gender: z.enum(["male", "female", "other", "prefer_not_to_say"]),
  
  // Step 3 data
  interests: z.array(z.string()).min(1, { message: "Please select at least one interest" }),
  
  // Step 4 data
  appRating: z.number().min(1).max(5),
  feedback: z.string().optional(),
  
  // Profile status
  isProfileComplete: z.boolean().default(true),
});

export type CompleteRegistrationData = z.infer<typeof completeRegistrationSchema>;
