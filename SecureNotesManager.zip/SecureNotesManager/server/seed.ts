import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { users, posts, comments, likes } from "@shared/schema";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seed() {
  console.log("Starting database seeding...");
  
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is not set");
  }

  const sql = neon(process.env.DATABASE_URL);
  const db = drizzle(sql);

  // Create test users
  console.log("Creating users...");
  const user1 = await db.insert(users).values({
    username: "johndoe",
    email: "john@example.com",
    password: await hashPassword("Password123!"),
    fullName: "John Doe",
    isVerified: true,
    profilePicture: null
  }).returning();

  const user2 = await db.insert(users).values({
    username: "janedoe",
    email: "jane@example.com",
    password: await hashPassword("Password123!"),
    fullName: "Jane Doe",
    isVerified: true,
    profilePicture: null
  }).returning();

  console.log(`Created users: ${user1[0].username}, ${user2[0].username}`);

  // Create posts
  console.log("Creating posts...");
  const post1 = await db.insert(posts).values({
    userId: user1[0].id,
    content: "For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life. - John 3:16",
    mediaUrl: null,
    mediaType: null
  }).returning();

  const post2 = await db.insert(posts).values({
    userId: user2[0].id,
    content: "The Lord is my shepherd, I lack nothing. He makes me lie down in green pastures, he leads me beside quiet waters, he refreshes my soul. - Psalm 23:1-2",
    mediaUrl: null,
    mediaType: null
  }).returning();

  const post3 = await db.insert(posts).values({
    userId: user1[0].id,
    content: "Be strong and courageous. Do not be afraid; do not be discouraged, for the Lord your God will be with you wherever you go. - Joshua 1:9",
    mediaUrl: null,
    mediaType: null
  }).returning();

  console.log(`Created ${post1.length + post2.length + post3.length} posts`);

  // Create comments
  console.log("Creating comments...");
  const comment1 = await db.insert(comments).values({
    postId: post1[0].id,
    userId: user2[0].id,
    content: "Amen! Such a powerful verse."
  }).returning();

  const comment2 = await db.insert(comments).values({
    postId: post2[0].id,
    userId: user1[0].id,
    content: "This has always been a source of comfort for me."
  }).returning();

  console.log(`Created ${comment1.length + comment2.length} comments`);

  // Create likes
  console.log("Creating likes...");
  const like1 = await db.insert(likes).values({
    postId: post1[0].id,
    userId: user2[0].id
  }).returning();

  const like2 = await db.insert(likes).values({
    postId: post2[0].id,
    userId: user1[0].id
  }).returning();

  const like3 = await db.insert(likes).values({
    postId: post3[0].id,
    userId: user2[0].id
  }).returning();

  console.log(`Created ${like1.length + like2.length + like3.length} likes`);

  console.log("Database seeding completed successfully!");
}

seed().catch(error => {
  console.error("Error seeding database:", error);
  process.exit(1);
});