import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";
import { z } from "zod";
import { registerSchema, loginSchema, emailVerificationSchema, phoneVerificationSchema, initialRegistrationSchema, forgotPasswordSchema } from "@shared/schema";
import nodemailer from "nodemailer";

import { NextFunction, Request, Response } from "express";
import { SessionData } from "express-session";

// Type for our pending user in session
interface PendingUser {
  username: string;
  email: string;
  password: string;
  fullName: string | null;
  createdAt: Date;
  isVerified: boolean;
  profilePicture: string | null;
}

// Type for pending OTP data
interface PendingOtp {
  otp: string;
  expiresAt: Date;
}

// Extend express-session declarations
declare module "express-session" {
  interface SessionData {
    pendingUser?: PendingUser;
    pendingOtp?: PendingOtp;
  }
}

declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      email: string;
      fullName: string | null;
      password: string;
      createdAt: Date;
      isVerified: boolean;
      profilePicture: string | null;
    }
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Generate a random 6-digit OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Email transporter setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false // For development only, remove in production
  }
});

// Send verification email with OTP
async function sendVerificationEmail(email: string, otp: string) {
  try {
    // Remove console log in production, replace with proper logging
    console.log(`Sending verification email to ${email} with OTP: ${otp}`);
    
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Kode Verifikasi - Faith Connect',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #b8860b; text-align: center;">Faith Connect</h2>
          <h3 style="color: #333;">Verifikasi Email Anda</h3>
          <p>Thank you for registering with Faith Connect. Please use the verification code below to complete your registration:</p>
          <div style="background-color: #f8f8f8; padding: 15px; text-align: center; border-radius: 5px; margin: 20px 0;">
            <h2 style="color: #b8860b; letter-spacing: 5px; margin: 0;">${otp}</h2>
          </div>
          <p>This code will expire in 10 minutes for security reasons.</p>
          <p>If you didn't request this code, please ignore this email.</p>
          <div style="text-align: center; margin-top: 30px; color: #777; font-size: 12px;">
            <p>Faith Connect - Growing Together in Faith</p>
          </div>
        </div>
      `
    };
    
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.response);
    return true;
  } catch (error) {
    console.error('Error sending verification email:', error);
    return false;
  }
}

// Send password reset email
async function sendPasswordResetEmail(email: string, resetToken: string) {
  try {
    console.log(`Sending password reset email to ${email}`);
    
    const resetLink = `${process.env.APP_URL || 'http://localhost:5000'}/reset-password?token=${resetToken}`;
    
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Reset Your Password - Faith Connect',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #b8860b; text-align: center;">Faith Connect</h2>
          <h3 style="color: #333;">Password Reset Request</h3>
          <p>We received a request to reset your password. Click the button below to create a new password:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetLink}" style="background-color: #b8860b; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">Reset Password</a>
          </div>
          <p>If you didn't request a password reset, please ignore this email or contact support if you have concerns.</p>
          <p>This link will expire in 1 hour for security reasons.</p>
          <div style="text-align: center; margin-top: 30px; color: #777; font-size: 12px;">
            <p>Faith Connect - Growing Together in Faith</p>
          </div>
        </div>
      `
    };
    
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.response);
    return true;
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "spiritual-journey-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 7 * 24 * 60 * 60 * 1000, // 1 week
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        }
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Rate limiting middleware for auth routes
  const loginAttempts = new Map<string, { count: number, lastAttempt: number }>();
  
  function rateLimiter(req: Request, res: Response, next: NextFunction) {
    const ip = req.ip || '';
    const now = Date.now();
    const windowMs = 15 * 60 * 1000; // 15 minutes
    const maxAttempts = 5;
    
    const record = loginAttempts.get(ip) || { count: 0, lastAttempt: now };
    
    // Reset if outside window
    if (now - record.lastAttempt > windowMs) {
      record.count = 0;
      record.lastAttempt = now;
    }
    
    record.count += 1;
    loginAttempts.set(ip, record);
    
    if (record.count > maxAttempts) {
      return res.status(429).json({ message: "Too many requests, please try again later." });
    }
    
    next();
  }

  // User Registration - Step 1: Collect info and send OTP
  app.post("/api/register", rateLimiter, async (req, res, next) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUserByUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingUserByEmail = await storage.getUserByEmail(validatedData.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Hash password
      const hashedPassword = await hashPassword(validatedData.password);
      
      // Create temporary pending user object in session (not in database yet)
      req.session.pendingUser = {
        username: validatedData.username,
        email: validatedData.email,
        password: hashedPassword,
        fullName: validatedData.fullName || null,
        createdAt: new Date(),
        isVerified: false,
        profilePicture: null
      };
      
      // Generate OTP for verification
      const otp = generateOTP();
      const expiryTime = new Date();
      expiryTime.setMinutes(expiryTime.getMinutes() + 10); // OTP expires in 10 minutes
      
      // Store OTP in session
      req.session.pendingOtp = {
        otp,
        expiresAt: expiryTime
      };
      
      // Send verification email
      await sendVerificationEmail(validatedData.email, otp);
      
      // Return temporary user data (no real ID yet)
      res.status(201).json({
        ...req.session.pendingUser,
        id: -1, // Temporary ID to indicate pending status
        password: "[PROTECTED]" // Don't expose password hash
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      next(error);
    }
  });

  // User Login
  app.post("/api/login", rateLimiter, async (req, res, next) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      
      passport.authenticate("local", (err: any, user: any, info: any) => {
        if (err) return next(err);
        if (!user) return res.status(401).json({ message: "Invalid username or password" });
        
        req.login(user, (err) => {
          if (err) return next(err);
          return res.status(200).json(user);
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      next(error);
    }
  });

  // User Logout
  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Get Current User
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    res.status(200).json(req.user);
  });

  // Verify OTP - Step 2: Verify OTP and create user in database
  app.post("/api/verify-otp", rateLimiter, async (req, res, next) => {
    try {
      const validatedData = emailVerificationSchema.parse(req.body);
      const { otp, email } = validatedData;
      
      // Check if we have pending user data in session
      if (!req.session.pendingUser || !req.session.pendingOtp) {
        console.log("No pending user or OTP in session");
        console.log("Session data:", JSON.stringify({
          hasPendingUser: !!req.session.pendingUser,
          hasPendingOtp: !!req.session.pendingOtp
        }));
        return res.status(400).json({ message: "Sesi registrasi telah berakhir. Silakan mendaftar kembali." });
      }
      
      console.log("Current session OTP:", req.session.pendingOtp.otp);
      console.log("User provided OTP:", otp);
      console.log("Email in session:", req.session.pendingUser.email);
      console.log("User provided email:", email);
      
      // Verify the email matches the pending user
      if (req.session.pendingUser.email !== email) {
        return res.status(400).json({ message: "Email tidak cocok. Silakan coba lagi." });
      }
      
      // Check OTP validity
      if (req.session.pendingOtp.otp !== otp) {
        return res.status(400).json({ message: "Kode verifikasi tidak valid" });
      }
      
      // Check OTP expiration
      if (new Date() > new Date(req.session.pendingOtp.expiresAt)) {
        return res.status(400).json({ message: "Kode verifikasi telah kedaluwarsa" });
      }
      
      // At this point, OTP is valid - now we can create the user in the database
      const newUser = await storage.createUser({
        username: req.session.pendingUser.username,
        email: req.session.pendingUser.email,
        password: req.session.pendingUser.password,
        fullName: req.session.pendingUser.fullName,
        isVerified: true, // User is verified immediately
        profilePicture: null
      });
      
      // Clear the pending data from session
      delete req.session.pendingUser;
      delete req.session.pendingOtp;
      
      // Log the user in automatically
      req.login(newUser, (err) => {
        if (err) return next(err);
        return res.status(200).json(newUser);
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      next(error);
    }
  });

  // Reset OTP (resend)
  app.post("/api/resend-otp", rateLimiter, async (req, res, next) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // For pending registration (user not in database yet)
      if (req.session.pendingUser && req.session.pendingUser.email === email) {
        // Generate new OTP
        const otp = generateOTP();
        const expiryTime = new Date();
        expiryTime.setMinutes(expiryTime.getMinutes() + 10); // OTP expires in 10 minutes
        
        // Update OTP in session
        req.session.pendingOtp = {
          otp,
          expiresAt: expiryTime
        };
        
        // Send verification email
        await sendVerificationEmail(email, otp);
        
        return res.status(200).json({ message: "OTP resent successfully" });
      }
      
      // For existing users (already in database)
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(400).json({ message: "User not found" });
      }
      
      // If user already verified, no need to resend OTP
      if (user.isVerified) {
        return res.status(400).json({ message: "User already verified" });
      }
      
      // Delete existing OTP if any
      try {
        await storage.deleteEmailOtpVerification(email);
      } catch (error) {
        // Ignore if no OTP exists
      }
      
      // Generate new OTP
      const otp = generateOTP();
      const expiryTime = new Date();
      expiryTime.setMinutes(expiryTime.getMinutes() + 10); // OTP expires in 10 minutes
      
      await storage.createEmailOtpVerification({
        email,
        otp,
        expiresAt: expiryTime,
        isVerified: false
      });
      
      // Send verification email
      await sendVerificationEmail(email, otp);
      
      res.status(200).json({ message: "OTP resent successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Forgot Password
  app.post("/api/forgot-password", rateLimiter, async (req, res, next) => {
    try {
      const validatedData = forgotPasswordSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUserByEmail(validatedData.email);
      
      if (!user) {
        // Don't reveal that the email doesn't exist for security
        return res.status(200).json({ message: "If your email is registered, you will receive a reset link" });
      }
      
      // Generate a reset token
      const resetToken = randomBytes(32).toString("hex");
      
      // In a real app, store the token with an expiry
      // Here we're just simulating the flow
      
      // Send reset email
      await sendPasswordResetEmail(user.email, resetToken);
      
      res.status(200).json({ message: "If your email is registered, you will receive a reset link" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      next(error);
    }
  });
}
