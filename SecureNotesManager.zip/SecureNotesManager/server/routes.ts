import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Post creation
  app.post("/api/posts", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const userId = req.user.id;
      const validatedData = insertPostSchema.parse({ ...req.body, userId });
      
      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      next(error);
    }
  });

  // Get posts feed
  app.get("/api/posts", async (req, res, next) => {
    try {
      const page = Number(req.query.page) || 1;
      const limit = Number(req.query.limit) || 10;
      
      const posts = await storage.getPosts(page, limit);
      res.status(200).json(posts);
    } catch (error) {
      next(error);
    }
  });

  // Add comment to post
  app.post("/api/posts/:postId/comments", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const userId = req.user.id;
      const postId = Number(req.params.postId);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      const validatedData = insertCommentSchema.parse({
        ...req.body,
        userId,
        postId,
      });
      
      const comment = await storage.createComment(validatedData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      next(error);
    }
  });

  // Like/unlike post
  app.post("/api/posts/:postId/like", async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const userId = req.user.id;
      const postId = Number(req.params.postId);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      const existingLike = await storage.getLike(postId, userId);
      
      if (existingLike) {
        await storage.deleteLike(postId, userId);
        res.status(200).json({ liked: false });
      } else {
        await storage.createLike({ postId, userId });
        res.status(200).json({ liked: true });
      }
    } catch (error) {
      next(error);
    }
  });

  // Get post comments
  app.get("/api/posts/:postId/comments", async (req, res, next) => {
    try {
      const postId = Number(req.params.postId);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      const comments = await storage.getCommentsByPostId(postId);
      res.status(200).json(comments);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
