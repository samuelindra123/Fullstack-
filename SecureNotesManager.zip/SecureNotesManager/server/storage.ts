import {
  users,
  posts,
  comments,
  likes,
  emailOtpVerifications,
  phoneOtpVerifications,
  type User,
  type InsertUser,
  type Post,
  type Comment,
  type Like,
  type EmailOtpVerification,
  type PhoneOtpVerification,
  type InsertPost,
  type InsertComment,
  type InsertLike,
  type InsertEmailOtpVerification,
  type InsertPhoneOtpVerification
} from "@shared/schema";
import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Interface for storage operations
export interface IStorage {
  // Session storage
  sessionStore: any;

  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyUser(id: number): Promise<User>;

  // OTP verification operations
  createEmailOtpVerification(verification: InsertEmailOtpVerification): Promise<EmailOtpVerification>;
  getEmailOtpVerification(email: string): Promise<EmailOtpVerification | undefined>;
  deleteEmailOtpVerification(email: string): Promise<void>;
  
  createPhoneOtpVerification(verification: InsertPhoneOtpVerification): Promise<PhoneOtpVerification>;
  getPhoneOtpVerification(phoneNumber: string): Promise<PhoneOtpVerification | undefined>;
  deletePhoneOtpVerification(phoneNumber: string): Promise<void>;

  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getPosts(page: number, limit: number): Promise<Post[]>;
  getPostById(id: number): Promise<Post | undefined>;
  getUserPosts(userId: number): Promise<Post[]>;

  // Comment operations
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByPostId(postId: number): Promise<Comment[]>;

  // Like operations
  createLike(like: InsertLike): Promise<Like>;
  getLike(postId: number, userId: number): Promise<Like | undefined>;
  deleteLike(postId: number, userId: number): Promise<void>;
  getLikesByPostId(postId: number): Promise<Like[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private likes: Map<number, Like>;
  private emailOtpVerifications: Map<string, EmailOtpVerification>;
  private phoneOtpVerifications: Map<string, PhoneOtpVerification>;
  sessionStore: any;
  currentUserId: number;
  currentPostId: number;
  currentCommentId: number;
  currentLikeId: number;
  currentOtpId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.emailOtpVerifications = new Map();
    this.phoneOtpVerifications = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    this.currentUserId = 1;
    this.currentPostId = 1;
    this.currentCommentId = 1;
    this.currentLikeId = 1;
    this.currentOtpId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    
    // Ensure all fields are properly initialized with defaults
    const user: User = {
      ...userData,
      id,
      createdAt: now,
      isVerified: userData.isVerified ?? false,
      phoneNumber: userData.phoneNumber ?? null,
      fullName: userData.fullName ?? null,
      channelUsername: userData.channelUsername ?? null,
      dateOfBirth: userData.dateOfBirth ?? null, 
      gender: userData.gender ?? null,
      interests: userData.interests ?? [],
      appRating: userData.appRating ?? null,
      feedback: userData.feedback ?? null,
      isPhoneVerified: userData.isPhoneVerified ?? false,
      isProfileComplete: userData.isProfileComplete ?? false,
      registrationStep: userData.registrationStep ?? 1,
      profilePicture: userData.profilePicture ?? null,
    };
    
    this.users.set(id, user);
    return user;
  }

  async verifyUser(id: number): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser: User = {
      ...user,
      isVerified: true,
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Email OTP verification operations
  async createEmailOtpVerification(verification: InsertEmailOtpVerification): Promise<EmailOtpVerification> {
    const id = this.currentOtpId++;
    const now = new Date();
    const otp: EmailOtpVerification = {
      ...verification,
      id,
      createdAt: now,
      isVerified: false
    };
    this.emailOtpVerifications.set(verification.email, otp);
    return otp;
  }

  async getEmailOtpVerification(email: string): Promise<EmailOtpVerification | undefined> {
    return this.emailOtpVerifications.get(email);
  }

  async deleteEmailOtpVerification(email: string): Promise<void> {
    this.emailOtpVerifications.delete(email);
  }
  
  // Phone OTP verification operations
  async createPhoneOtpVerification(verification: InsertPhoneOtpVerification): Promise<PhoneOtpVerification> {
    const id = this.currentOtpId++;
    const now = new Date();
    const otp: PhoneOtpVerification = {
      ...verification,
      id,
      createdAt: now,
      isVerified: false
    };
    this.phoneOtpVerifications.set(verification.phoneNumber, otp);
    return otp;
  }

  async getPhoneOtpVerification(phoneNumber: string): Promise<PhoneOtpVerification | undefined> {
    return this.phoneOtpVerifications.get(phoneNumber);
  }

  async deletePhoneOtpVerification(phoneNumber: string): Promise<void> {
    this.phoneOtpVerifications.delete(phoneNumber);
  }

  // Post operations
  async createPost(postData: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const now = new Date();
    const post: Post = {
      ...postData,
      id,
      createdAt: now,
      mediaUrl: postData.mediaUrl ?? null,
      mediaType: postData.mediaType ?? null
    };
    this.posts.set(id, post);
    return post;
  }

  async getPosts(page: number, limit: number): Promise<Post[]> {
    const allPosts = Array.from(this.posts.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    
    return allPosts.slice(startIndex, endIndex);
  }

  async getPostById(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getUserPosts(userId: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Comment operations
  async createComment(commentData: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const now = new Date();
    const comment: Comment = {
      ...commentData,
      id,
      createdAt: now,
    };
    this.comments.set(id, comment);
    return comment;
  }

  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  // Like operations
  async createLike(likeData: InsertLike): Promise<Like> {
    const id = this.currentLikeId++;
    const now = new Date();
    const like: Like = {
      ...likeData,
      id,
      createdAt: now,
    };
    this.likes.set(id, like);
    return like;
  }

  async getLike(postId: number, userId: number): Promise<Like | undefined> {
    return Array.from(this.likes.values()).find(
      like => like.postId === postId && like.userId === userId
    );
  }

  async deleteLike(postId: number, userId: number): Promise<void> {
    const likeId = Array.from(this.likes.entries())
      .find(([_, like]) => like.postId === postId && like.userId === userId)?.[0];
    
    if (likeId) {
      this.likes.delete(likeId);
    }
  }

  async getLikesByPostId(postId: number): Promise<Like[]> {
    return Array.from(this.likes.values())
      .filter(like => like.postId === postId);
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;
  private db: ReturnType<typeof drizzle>;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is not set");
    }

    const sql = neon(process.env.DATABASE_URL);
    this.db = drizzle(sql);
    
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL
      },
      createTableIfMissing: true
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(userData: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(userData).returning();
    return result[0];
  }

  async verifyUser(id: number): Promise<User> {
    const result = await this.db
      .update(users)
      .set({ isVerified: true })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async createEmailOtpVerification(verification: InsertEmailOtpVerification): Promise<EmailOtpVerification> {
    const result = await this.db.insert(emailOtpVerifications).values(verification).returning();
    return result[0];
  }

  async getEmailOtpVerification(email: string): Promise<EmailOtpVerification | undefined> {
    const result = await this.db.select().from(emailOtpVerifications).where(eq(emailOtpVerifications.email, email));
    return result[0];
  }

  async deleteEmailOtpVerification(email: string): Promise<void> {
    await this.db.delete(emailOtpVerifications).where(eq(emailOtpVerifications.email, email));
  }
  
  async createPhoneOtpVerification(verification: InsertPhoneOtpVerification): Promise<PhoneOtpVerification> {
    const result = await this.db.insert(phoneOtpVerifications).values(verification).returning();
    return result[0];
  }

  async getPhoneOtpVerification(phoneNumber: string): Promise<PhoneOtpVerification | undefined> {
    const result = await this.db.select().from(phoneOtpVerifications).where(eq(phoneOtpVerifications.phoneNumber, phoneNumber));
    return result[0];
  }

  async deletePhoneOtpVerification(phoneNumber: string): Promise<void> {
    await this.db.delete(phoneOtpVerifications).where(eq(phoneOtpVerifications.phoneNumber, phoneNumber));
  }

  async createPost(postData: InsertPost): Promise<Post> {
    const result = await this.db.insert(posts).values(postData).returning();
    return result[0];
  }

  async getPosts(page: number, limit: number): Promise<Post[]> {
    const offset = (page - 1) * limit;
    return await this.db
      .select()
      .from(posts)
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getPostById(id: number): Promise<Post | undefined> {
    const result = await this.db.select().from(posts).where(eq(posts.id, id));
    return result[0];
  }

  async getUserPosts(userId: number): Promise<Post[]> {
    return await this.db
      .select()
      .from(posts)
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt));
  }

  async createComment(commentData: InsertComment): Promise<Comment> {
    const result = await this.db.insert(comments).values(commentData).returning();
    return result[0];
  }

  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return await this.db
      .select()
      .from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(comments.createdAt);
  }

  async createLike(likeData: InsertLike): Promise<Like> {
    const result = await this.db.insert(likes).values(likeData).returning();
    return result[0];
  }

  async getLike(postId: number, userId: number): Promise<Like | undefined> {
    const result = await this.db
      .select()
      .from(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
    return result[0];
  }

  async deleteLike(postId: number, userId: number): Promise<void> {
    await this.db
      .delete(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
  }

  async getLikesByPostId(postId: number): Promise<Like[]> {
    return await this.db
      .select()
      .from(likes)
      .where(eq(likes.postId, postId));
  }
}

// Change this line to use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
