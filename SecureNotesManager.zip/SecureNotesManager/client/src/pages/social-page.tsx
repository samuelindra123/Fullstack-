import { useState } from "react";
import SocialNavbar from "@/components/social/social-navbar";
import CreatePostModal from "@/components/social/create-post-modal";
import LeftSidebar from "@/components/social/left-sidebar";
import RightSidebar from "@/components/social/right-sidebar";
import { useQuery } from "@tanstack/react-query";
import { Post } from "@shared/schema";
import { Loader2 } from "lucide-react";
import PostCard from "@/components/social/post-card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export default function SocialPage() {
  const [showCreatePostModal, setShowCreatePostModal] = useState(false);
  const { user } = useAuth();
  const [page, setPage] = useState(1);
  const limit = 10;

  const { data: posts, isLoading, error, refetch } = useQuery<Post[]>({
    queryKey: ["/api/posts", { page, limit }],
  });

  const handleLoadMore = () => {
    setPage(prev => prev + 1);
  };

  const handleCreatePost = () => {
    setShowCreatePostModal(true);
  };

  const handleCloseModal = () => {
    setShowCreatePostModal(false);
  };

  const handlePostCreated = () => {
    refetch();
    setShowCreatePostModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <SocialNavbar />
      
      <div className="container mx-auto pt-20 px-4 lg:px-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-1/4 hidden lg:block">
            <LeftSidebar user={user} />
          </div>
          
          <div className="lg:w-2/4">
            {/* Create Post */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
              <div className="flex">
                <img 
                  src={user?.profilePicture || "https://ui-avatars.com/api/?name=" + user?.username}
                  alt="User profile" 
                  className="w-10 h-10 rounded-full object-cover mr-3"
                />
                <div 
                  className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-gray-500 cursor-pointer hover:bg-gray-200 transition-colors"
                  onClick={handleCreatePost}
                >
                  Share a spiritual thought, {user?.fullName || user?.username}...
                </div>
              </div>
              
              <div className="flex justify-between mt-4">
                <button className="flex items-center text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-md transition-colors">
                  <i className="fas fa-image text-green-500 mr-2"></i>
                  <span>Photo</span>
                </button>
                <button className="flex items-center text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-md transition-colors">
                  <i className="fas fa-video text-red-500 mr-2"></i>
                  <span>Video</span>
                </button>
                <button className="flex items-center text-gray-500 hover:bg-gray-100 px-4 py-2 rounded-md transition-colors">
                  <i className="fas fa-book-open text-purple-500 mr-2"></i>
                  <span>Scripture</span>
                </button>
              </div>
            </div>
            
            {/* Posts Feed */}
            {isLoading ? (
              <div className="flex justify-center my-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <p className="text-red-500">Failed to load posts. Please try again.</p>
              </div>
            ) : posts && posts.length > 0 ? (
              <>
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
                <div className="text-center my-8">
                  <Button 
                    variant="outline" 
                    onClick={handleLoadMore}
                    className="py-2 px-6 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-colors"
                  >
                    Load More
                  </Button>
                </div>
              </>
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <p className="text-gray-500">No posts yet. Be the first to share something!</p>
              </div>
            )}
          </div>
          
          <div className="lg:w-1/4 hidden lg:block">
            <RightSidebar />
          </div>
        </div>
      </div>
      
      {showCreatePostModal && (
        <CreatePostModal onClose={handleCloseModal} onPostCreated={handlePostCreated} />
      )}
    </div>
  );
}
