import Navbar from "@/components/landing/navbar";
import HeroSection from "@/components/landing/hero-section";
import FeaturesSection from "@/components/landing/features-section";
import TimelineSection from "@/components/landing/timeline-section";
import TestimonialsSection from "@/components/landing/testimonials-section";
import CallToActionSection from "@/components/landing/call-to-action-section";
import Footer from "@/components/landing/footer";

export default function HomePage() {
  return (
    <div className="min-h-screen font-sans bg-dark text-white">
      <Navbar />
      <main>
        <HeroSection />
        <FeaturesSection />
        <TimelineSection />
        <TestimonialsSection />
        <CallToActionSection />
      </main>
      <Footer />
    </div>
  );
}
