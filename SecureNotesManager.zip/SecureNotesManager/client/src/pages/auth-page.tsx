import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LoginForm from "@/components/auth/login-form";
import RegisterForm from "@/components/auth/register-form";
import OtpVerification from "@/components/auth/otp-verification";
import PhoneVerification from "@/components/auth/phone-verification";
import ForgotPassword from "@/components/auth/forgot-password";
import MultiStepRegistration from "@/components/auth/registration/multi-step-registration";
import { InitialRegistrationData } from "@shared/schema";

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>("login");
  const [authStep, setAuthStep] = useState<"initial" | "email-verification" | "phone-verification" | "registration">("initial");
  const [showForgotPassword, setShowForgotPassword] = useState<boolean>(false);
  const [registeredEmail, setRegisteredEmail] = useState<string>("");
  const [registeredPhone, setRegisteredPhone] = useState<string>("");
  const [initialUserData, setInitialUserData] = useState<InitialRegistrationData | null>(null);
  const { user } = useAuth();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    if (user?.isProfileComplete) {
      navigate("/social");
    }
  }, [user, navigate]);

  const handleRegisterSuccess = (email: string, userData: InitialRegistrationData) => {
    setRegisteredEmail(email);
    setRegisteredPhone(userData.phoneNumber);
    setInitialUserData(userData);
    setAuthStep("email-verification");
  };

  const handleForgotPasswordClick = () => {
    setShowForgotPassword(true);
  };

  const handleBackToLoginClick = () => {
    setShowForgotPassword(false);
  };

  const handleEmailVerificationSuccess = () => {
    setAuthStep("phone-verification");
  };

  const handlePhoneVerificationSuccess = () => {
    setAuthStep("registration");
  };

  const handleRegistrationComplete = () => {
    navigate("/social");
  };

  // Tampilkan formulir verifikasi email jika diperlukan
  if (authStep === "email-verification") {
    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4">
        <div className="container max-w-md">
          <OtpVerification 
            onSuccess={handleEmailVerificationSuccess} 
            email={registeredEmail} 
          />
        </div>
      </div>
    );
  }

  // Tampilkan formulir verifikasi telepon jika diperlukan
  if (authStep === "phone-verification") {
    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4">
        <div className="container max-w-md">
          <PhoneVerification 
            onSuccess={handlePhoneVerificationSuccess}
            phoneNumber={registeredPhone}
          />
        </div>
      </div>
    );
  }

  // Tampilkan formulir pendaftaran 4 langkah jika diperlukan
  if (authStep === "registration" && initialUserData) {
    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4">
        <div className="container max-w-md">
          <MultiStepRegistration 
            email={registeredEmail}
            onComplete={handleRegistrationComplete}
            initialUserData={initialUserData}
          />
        </div>
      </div>
    );
  }

  if (showForgotPassword) {
    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4">
        <div className="container max-w-md">
          <ForgotPassword onBackToLogin={handleBackToLoginClick} />
        </div>
      </div>
    );
  }

  return (
    <section className="min-h-screen flex items-center justify-center py-12 px-4">
      <div className="container flex flex-col lg:flex-row max-w-6xl gap-8">
        <div className="lg:flex-1 flex items-center justify-center">
          <div className="max-w-md w-full">
            <div className="mb-8 text-center">
              <h1 className="text-3xl font-bold mb-2">Selamat Datang</h1>
              <p className="text-muted-foreground">
                Masuk atau daftar untuk mengakses platform media sosial Kristen kami
              </p>
            </div>
            
            <div className="bg-card rounded-lg shadow-lg overflow-hidden">
              <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full grid grid-cols-2 bg-muted">
                  <TabsTrigger value="login" className="py-3 font-medium text-center">
                    Masuk
                  </TabsTrigger>
                  <TabsTrigger value="register" className="py-3 font-medium text-center">
                    Daftar
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="login" className="p-6">
                  <LoginForm onForgotPasswordClick={handleForgotPasswordClick} />
                </TabsContent>
                
                <TabsContent value="register" className="p-6">
                  <RegisterForm onSuccess={handleRegisterSuccess} />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
        
        <div className="lg:flex-1 hidden lg:flex flex-col items-center justify-center text-center px-6">
          <h2 className="text-2xl font-bold mb-4">Tumbuh Bersama dalam Iman</h2>
          <p className="text-lg mb-6">
            Bergabunglah dengan komunitas Kristen kami untuk berbagi, belajar,
            dan bertumbuh bersama dalam iman Kristiani.
          </p>
          <div className="grid grid-cols-2 gap-4 w-full max-w-md">
            <div className="bg-primary/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Komunitas</h3>
              <p className="text-sm">Terhubung dengan sesama anak Tuhan dari berbagai denominasi</p>
            </div>
            <div className="bg-primary/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Renungan</h3>
              <p className="text-sm">Dapatkan renungan harian dan inspirasi rohani</p>
            </div>
            <div className="bg-primary/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Diskusi</h3>
              <p className="text-sm">Terlibat dalam diskusi alkitabiah yang membangun</p>
            </div>
            <div className="bg-primary/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Doa</h3>
              <p className="text-sm">Berbagi pokok doa dan mendoakan sesama</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
