export default function RightSidebar() {
  const events = [
    {
      month: "JUL",
      day: "15",
      title: "Online Prayer Meeting",
      time: "7:00 PM - 8:30 PM",
      location: "Zoom",
      isVirtual: true
    },
    {
      month: "JUL",
      day: "22",
      title: "Bible Study Group",
      time: "6:30 PM - 8:00 PM",
      location: "Community Center",
      isVirtual: false
    },
    {
      month: "AUG",
      day: "05",
      title: "Worship Night",
      time: "5:00 PM - 7:00 PM",
      location: "Grace Church",
      isVirtual: false
    }
  ];

  const groups = [
    {
      name: "Prayer Warriors",
      members: "1.2K members",
      image: "https://ui-avatars.com/api/?name=Prayer+Warriors&background=8250c8&color=fff"
    },
    {
      name: "Bible Study",
      members: "845 members",
      image: "https://ui-avatars.com/api/?name=Bible+Study&background=2563eb&color=fff"
    },
    {
      name: "Worship Music",
      members: "632 members",
      image: "https://ui-avatars.com/api/?name=Worship+Music&background=15803d&color=fff"
    }
  ];

  return (
    <div>
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h3 className="font-medium text-lg mb-4">Upcoming Events</h3>
        
        <div className="space-y-4">
          {events.map((event, index) => (
            <div key={index} className="border-b border-gray-100 pb-4">
              <div className="flex items-start">
                <div className="bg-purple-900 text-white text-center rounded p-2 mr-3">
                  <div className="text-sm font-medium">{event.month}</div>
                  <div className="text-xl font-bold">{event.day}</div>
                </div>
                <div>
                  <h4 className="font-medium">{event.title}</h4>
                  <p className="text-gray-500 text-sm">{event.time}</p>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    {event.isVirtual ? (
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                        <polygon points="23 7 16 12 23 17 23 7"/>
                        <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                        <circle cx="12" cy="10" r="3"/>
                      </svg>
                    )}
                    <span>{event.location}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          <a href="#" className="block text-center text-purple-700 hover:underline">
            See all events
          </a>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="font-medium text-lg mb-4">Recommended Groups</h3>
        
        <div className="space-y-4">
          {groups.map((group, index) => (
            <div key={index} className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-gray-200 mr-3 overflow-hidden">
                <img 
                  src={group.image}
                  alt={group.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <h4 className="font-medium">{group.name}</h4>
                <p className="text-gray-500 text-sm">{group.members}</p>
              </div>
              <button className="py-1 px-3 border border-purple-700 text-purple-700 rounded-full text-sm hover:bg-purple-700 hover:text-white transition-colors">
                Join
              </button>
            </div>
          ))}
          
          <a href="#" className="block text-center text-purple-700 hover:underline">
            Discover more groups
          </a>
        </div>
      </div>
    </div>
  );
}
