import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Post, Comment, User } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Loader2 } from "lucide-react";

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [comment, setComment] = useState("");
  const [showComments, setShowComments] = useState(false);

  // Get post author
  const { data: author } = useQuery<User>({
    queryKey: [`/api/users/${post.userId}`],
    enabled: !!post.userId,
  });

  // Get post likes
  const { data: likes, refetch: refetchLikes } = useQuery<number>({
    queryKey: [`/api/posts/${post.id}/likes/count`],
    enabled: !!post.id,
  });

  // Get my like status
  const { data: isLiked, refetch: refetchIsLiked } = useQuery<boolean>({
    queryKey: [`/api/posts/${post.id}/likes/status`],
    enabled: !!post.id && !!user,
  });

  // Get post comments
  const { data: comments, isLoading: isLoadingComments, refetch: refetchComments } = useQuery<Comment[]>({
    queryKey: [`/api/posts/${post.id}/comments`],
    enabled: !!post.id && showComments,
  });

  // Like/unlike post mutation
  const likeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/like`);
      return await res.json();
    },
    onSuccess: () => {
      refetchLikes();
      refetchIsLiked();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to like post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Comment on post mutation
  const commentMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/comments`, { content: comment });
      return await res.json();
    },
    onSuccess: () => {
      setComment("");
      refetchComments();
      toast({
        title: "Comment added",
        description: "Your comment has been posted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to post comment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLikeClick = () => {
    if (likeMutation.isPending) return;
    likeMutation.mutate();
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;
    commentMutation.mutate();
  };

  const toggleComments = () => {
    setShowComments(!showComments);
  };

  const formatDate = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm mb-6">
      <div className="p-4">
        <div className="flex items-center mb-3">
          <img 
            src={author?.profilePicture || `https://ui-avatars.com/api/?name=${author?.username || 'User'}`}
            alt={author?.username || 'User'} 
            className="w-10 h-10 rounded-full object-cover mr-3"
          />
          <div>
            <h4 className="font-medium">{author?.fullName || author?.username || 'User'}</h4>
            <p className="text-gray-500 text-sm">{formatDate(post.createdAt)}</p>
          </div>
          <button className="ml-auto text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="1"/>
              <circle cx="19" cy="12" r="1"/>
              <circle cx="5" cy="12" r="1"/>
            </svg>
          </button>
        </div>
        
        <p className="mb-4">{post.content}</p>
        
        {post.mediaUrl && post.mediaType === 'image' && (
          <img 
            src={post.mediaUrl}
            alt="Post content" 
            className="w-full h-80 object-cover rounded-lg mb-4"
          />
        )}
        
        {post.mediaUrl && post.mediaType === 'video' && (
          <div className="relative rounded-lg overflow-hidden mb-4 bg-gray-800">
            <video 
              src={post.mediaUrl}
              className="w-full h-80 object-cover"
              controls
            ></video>
          </div>
        )}
        
        <div className="flex justify-between text-gray-500 border-t border-gray-100 pt-3">
          <div className="flex items-center">
            <button 
              className={`flex items-center ${isLiked ? 'text-purple-700' : 'hover:text-purple-700'}`}
              onClick={handleLikeClick}
              disabled={likeMutation.isPending}
            >
              {likeMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-1" />
              ) : (
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="16" 
                  height="16" 
                  viewBox="0 0 24 24" 
                  fill={isLiked ? "currentColor" : "none"} 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="mr-1"
                >
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
              )}
              <span>{likes || 0}</span>
            </button>
            <button className="flex items-center ml-4 hover:text-purple-700" onClick={toggleComments}>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
              </svg>
              <span>{comments?.length || 0}</span>
            </button>
          </div>
          <button className="flex items-center hover:text-purple-700">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
              <polyline points="16 6 12 2 8 6"/>
              <line x1="12" x2="12" y1="2" y2="15"/>
            </svg>
            <span>Share</span>
          </button>
        </div>
        
        {showComments && (
          <div className="border-t border-gray-100 mt-3 pt-3">
            <form onSubmit={handleCommentSubmit} className="flex mb-3">
              <img 
                src={user?.profilePicture || `https://ui-avatars.com/api/?name=${user?.username || 'User'}`}
                alt="User profile" 
                className="w-8 h-8 rounded-full object-cover mr-2"
              />
              <div className="flex-1 relative">
                <input 
                  type="text" 
                  placeholder="Write a comment..." 
                  className="w-full bg-gray-100 rounded-full px-4 py-2 pr-10 text-sm focus:outline-none"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                />
                <button 
                  type="submit"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-700"
                  disabled={commentMutation.isPending || !comment.trim()}
                >
                  {commentMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="22" x2="11" y1="2" y2="13"/>
                      <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                    </svg>
                  )}
                </button>
              </div>
            </form>
            
            {isLoadingComments ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-purple-700" />
              </div>
            ) : comments && comments.length > 0 ? (
              <div className="ml-10 space-y-3">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex">
                    <img 
                      src={`https://ui-avatars.com/api/?name=User`}
                      alt="User" 
                      className="w-8 h-8 rounded-full object-cover mr-2"
                    />
                    <div className="bg-gray-100 rounded-2xl px-4 py-2">
                      <h5 className="font-medium text-sm">User</h5>
                      <p className="text-gray-700">{comment.content}</p>
                      <p className="text-xs text-gray-500 mt-1">{formatDate(comment.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-2 text-sm">No comments yet. Be the first to comment!</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
