import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ForgotPasswordData, forgotPasswordSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

interface ForgotPasswordProps {
  onBackToLogin: () => void;
}

export default function ForgotPassword({ onBackToLogin }: ForgotPasswordProps) {
  const { forgotPasswordMutation } = useAuth();

  const form = useForm<ForgotPasswordData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit = (data: ForgotPasswordData) => {
    forgotPasswordMutation.mutate(data);
  };

  return (
    <div className="bg-dark-light rounded-lg shadow-xl overflow-hidden">
      <div className="p-6">
        <h2 className="font-serif text-2xl text-gold mb-3 text-center">Reset Password</h2>
        <p className="text-gray-300 text-center mb-6">Enter your email address and we'll send you a link to reset your password.</p>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Email Address</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="email"
                      placeholder="your@email.com" 
                      className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full py-3 bg-gold text-dark font-medium rounded hover:bg-amber-600 transition-colors"
              disabled={forgotPasswordMutation.isPending}
            >
              {forgotPasswordMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Send Reset Link
            </Button>
            
            <div className="text-center mt-4">
              <button 
                type="button" 
                className="text-gold hover:underline"
                onClick={onBackToLogin}
              >
                Back to Sign In
              </button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
