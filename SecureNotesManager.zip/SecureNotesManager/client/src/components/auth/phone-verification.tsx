import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { PhoneVerificationData, phoneVerificationSchema } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface PhoneVerificationProps {
  onSuccess: () => void;
  phoneNumber: string;
}

export default function PhoneVerification({ onSuccess, phoneNumber }: PhoneVerificationProps) {
  const { toast } = useToast();
  const { verifyPhoneOtpMutation } = useAuth();
  const [otpSent, setOtpSent] = useState(true); // Assuming OTP is sent when component is mounted

  const form = useForm<PhoneVerificationData>({
    resolver: zodResolver(phoneVerificationSchema),
    defaultValues: {
      otp: "",
      phoneNumber: phoneNumber,
    },
  });

  const onSubmit = (data: PhoneVerificationData) => {
    verifyPhoneOtpMutation.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Nomor Telepon Terverifikasi",
          description: "Nomor telepon Anda telah berhasil diverifikasi.",
        });
        onSuccess();
      },
      onError: (error) => {
        toast({
          title: "Verifikasi Gagal",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <div className="space-y-6 w-full max-w-md mx-auto">
      <div className="text-center">
        <h1 className="text-2xl font-bold">Verifikasi Nomor Telepon</h1>
        <p className="text-muted-foreground mt-2">
          Silakan masukkan kode OTP 6 digit yang dikirimkan ke nomor telepon Anda
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="otp"
            render={({ field }) => (
              <FormItem className="mx-auto">
                <FormLabel className="text-center block">Kode OTP</FormLabel>
                <FormControl>
                  <InputOTP
                    maxLength={6}
                    {...field}
                    render={({ slots }) => (
                      <InputOTPGroup>
                        {slots.map((slot, idx) => (
                          <InputOTPSlot key={idx} {...slot} index={idx} />
                        ))}
                      </InputOTPGroup>
                    )}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="phoneNumber"
            render={({ field }) => (
              <FormItem className="hidden">
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />

          <Button
            type="submit"
            className="w-full"
            disabled={verifyPhoneOtpMutation.isPending}
          >
            {verifyPhoneOtpMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Memverifikasi...
              </>
            ) : (
              "Verifikasi"
            )}
          </Button>
        </form>
      </Form>

      <div className="text-center text-sm">
        <Button
          variant="link"
          className="p-0 h-auto"
          onClick={() => {
            toast({
              title: "Kode OTP Baru Telah Dikirim",
              description: "Silakan cek ponsel Anda untuk kode OTP baru.",
            });
          }}
          disabled={verifyPhoneOtpMutation.isPending}
        >
          Kirim Ulang Kode OTP
        </Button>
      </div>
    </div>
  );
}