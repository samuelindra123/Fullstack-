import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { EmailVerificationData, emailVerificationSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Loader2 } from "lucide-react";

interface OtpVerificationProps {
  onSuccess: () => void;
  email?: string; // Pass email from register form
}

export default function OtpVerification({ onSuccess, email = "" }: OtpVerificationProps) {
  const { verifyOtpMutation } = useAuth();
  const { toast } = useToast();
  const [timer, setTimer] = useState<number>(300); // 5 minutes in seconds
  const [timerRunning, setTimerRunning] = useState<boolean>(true);
  const timerRef = useRef<number | null>(null);
  const inputRefs = useRef<Array<HTMLInputElement | null>>(Array(6).fill(null));

  const form = useForm<EmailVerificationData>({
    resolver: zodResolver(emailVerificationSchema),
    defaultValues: {
      otp: "",
      email: email,
    },
  });

  // If email is passed as prop, update form value
  useEffect(() => {
    if (email) {
      form.setValue("email", email);
    }
  }, [email, form]);

  const onSubmit = (data: EmailVerificationData) => {
    verifyOtpMutation.mutate(data, {
      onSuccess: () => {
        onSuccess();
      },
    });
  };

  const handleResendOtp = async () => {
    // Reset timer
    setTimer(300);
    setTimerRunning(true);
    
    try {
      // Call resend OTP API with email
      const response = await fetch('/api/resend-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: form.getValues('email') }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        // Show success toast
        toast({
          title: "OTP Resent",
          description: "A new verification code has been sent to your email",
        });
      } else {
        // Show error toast
        toast({
          title: "Error",
          description: data.message || "Failed to resend verification code",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error resending OTP:", error);
      toast({
        title: "Error",
        description: "Failed to resend verification code",
        variant: "destructive",
      });
    }
  };

  const handleInputChange = (index: number, value: string) => {
    // Update the form state with the new digit
    const currentOtp = form.getValues("otp") || "";
    const newOtp = currentOtp.split("");
    newOtp[index] = value;
    const updatedOtp = newOtp.join("");
    form.setValue("otp", updatedOtp);
    
    console.log("Current OTP state:", updatedOtp);
    
    // Move focus to next input if current input is filled
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !form.getValues("otp")[index] && index > 0) {
      // Move to previous input when backspace is pressed on an empty input
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").slice(0, 6);
    
    if (/^\d+$/.test(pastedData)) {
      form.setValue("otp", pastedData);
      
      // Update each input field
      for (let i = 0; i < pastedData.length; i++) {
        if (inputRefs.current[i]) {
          const inputElement = inputRefs.current[i] as HTMLInputElement;
          inputElement.value = pastedData[i];
        }
      }
      
      // Focus the last filled input or the next empty one
      const focusIndex = Math.min(pastedData.length, 5);
      inputRefs.current[focusIndex]?.focus();
    }
  };

  useEffect(() => {
    if (timerRunning) {
      timerRef.current = window.setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer <= 1) {
            setTimerRunning(false);
            clearInterval(timerRef.current!);
            return 0;
          }
          return prevTimer - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [timerRunning]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  return (
    <div className="bg-dark-light rounded-lg shadow-xl overflow-hidden">
      <div className="p-6">
        <h2 className="font-serif text-2xl text-gold mb-3 text-center">Verify Your Email</h2>
        <p className="text-gray-300 text-center mb-6">We've sent a verification code to your email. Please enter it below.</p>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="otp"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <InputOTP
                      maxLength={6}
                      {...field}
                      render={({ slots }) => (
                        <InputOTPGroup>
                          {slots.map((slot, idx) => (
                            <InputOTPSlot key={idx} {...slot} index={idx} />
                          ))}
                        </InputOTPGroup>
                      )}
                    />
                  </FormControl>
                  <FormMessage className="text-center mt-2" />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full py-3 bg-gold text-dark font-medium rounded hover:bg-amber-600 transition-colors"
              disabled={verifyOtpMutation.isPending}
            >
              {verifyOtpMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Verify Account
            </Button>
            
            <div className="text-center mt-4">
              <p className="text-gray-400 text-sm">
                Didn't receive the code?{' '}
                <button 
                  type="button" 
                  className={`text-gold ${!timerRunning ? 'hover:underline' : 'opacity-50 cursor-not-allowed'}`}
                  onClick={handleResendOtp}
                  disabled={timerRunning}
                >
                  Resend Code
                </button>
              </p>
              <p className="text-gray-400 text-xs mt-2">
                Code expires in <span>{formatTime(timer)}</span>
              </p>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
