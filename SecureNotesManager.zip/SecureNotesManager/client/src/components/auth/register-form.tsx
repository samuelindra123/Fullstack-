import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { registerSchema, RegisterData } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Loader2, Eye, EyeOff, Check, X } from "lucide-react";

interface RegisterFormProps {
  onSuccess: (email: string, userData: any) => void;
}

export default function RegisterForm({ onSuccess }: RegisterFormProps) {
  const { registerMutation } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [termsDialogOpen, setTermsDialogOpen] = useState(false);
  const [privacyDialogOpen, setPrivacyDialogOpen] = useState(false);

  const form = useForm<RegisterData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      fullName: "",
      username: "",
      email: "",
      phoneNumber: "",
      password: "",
      confirmPassword: "",
      termsAccepted: false
    }
  });

  const password = form.watch("password");

  const passwordStrength = {
    hasLength: password.length >= 8,
    hasUppercase: /[A-Z]/.test(password),
    hasNumber: /[0-9]/.test(password),
    hasSpecial: /[^a-zA-Z0-9]/.test(password),
  };

  const onSubmit = (data: RegisterData) => {
    registerMutation.mutate(data, {
      onSuccess: () => {
        // Pass both email and the initial user data to the parent component
        const initialUserData = {
          username: data.username,
          email: data.email,
          password: data.password,
          phoneNumber: data.phoneNumber || "",
          fullName: data.fullName,
        };
        onSuccess(data.email, initialUserData);
      }
    });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <>
      <h2 className="font-serif text-2xl text-gold mb-6 text-center">Create Account</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-300">Full Name</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    value={field.value || ''}
                    placeholder="John Doe" 
                    className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-300">Username</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    value={field.value || ''}
                    placeholder="johndoe" 
                    className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-300">Email Address</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    value={field.value || ''}
                    type="email"
                    placeholder="your@email.com" 
                    className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="phoneNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-300">Nomor Telepon</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    value={field.value || ''}
                    type="tel"
                    placeholder="+6281234567890" 
                    className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-300">Create Password</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input 
                      {...field} 
                      value={field.value || ''}
                      type={showPassword ? "text" : "password"} 
                      placeholder="••••••••" 
                      className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                    />
                    <button 
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300"
                      onClick={togglePasswordVisibility}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </FormControl>
                <div className="mt-2">
                  <div className="text-xs text-gray-400 mb-1">Password must contain:</div>
                  <ul className="text-xs text-gray-400 space-y-1">
                    <li className="flex items-center">
                      {passwordStrength.hasLength ? 
                        <Check size={12} className="text-green-500 mr-1" /> : 
                        <X size={12} className="text-red-500 mr-1" />}
                      At least 8 characters
                    </li>
                    <li className="flex items-center">
                      {passwordStrength.hasUppercase ? 
                        <Check size={12} className="text-green-500 mr-1" /> : 
                        <X size={12} className="text-red-500 mr-1" />}
                      At least one uppercase letter
                    </li>
                    <li className="flex items-center">
                      {passwordStrength.hasNumber ? 
                        <Check size={12} className="text-green-500 mr-1" /> : 
                        <X size={12} className="text-red-500 mr-1" />}
                      At least one number
                    </li>
                    <li className="flex items-center">
                      {passwordStrength.hasSpecial ? 
                        <Check size={12} className="text-green-500 mr-1" /> : 
                        <X size={12} className="text-red-500 mr-1" />}
                      At least one special character
                    </li>
                  </ul>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="confirmPassword"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-300">Confirm Password</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    value={field.value || ''}
                    type={showPassword ? "text" : "password"} 
                    placeholder="••••••••" 
                    className="w-full px-4 py-3 rounded bg-background border border-gray-700 text-white focus:outline-none focus:border-gold"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="termsAccepted"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                <FormControl>
                  <Checkbox 
                    id="termsAccepted"
                    checked={field.value}
                    onCheckedChange={(checked) => {
                      field.onChange(checked);
                    }}
                    className="h-6 w-6 border-2 border-gray-500 rounded-sm data-[state=checked]:bg-gold data-[state=checked]:border-gold"
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel htmlFor="termsAccepted" className="text-sm text-gray-300 cursor-pointer">
                    I agree to the <button 
                      type="button" 
                      className="text-gold hover:underline"
                      onClick={() => setTermsDialogOpen(true)}
                    >
                      Terms of Service
                    </button> and <button 
                      type="button" 
                      className="text-gold hover:underline"
                      onClick={() => setPrivacyDialogOpen(true)}
                    >
                      Privacy Policy
                    </button>
                  </FormLabel>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="w-full py-3 bg-gold text-dark font-medium rounded hover:bg-amber-600 transition-colors"
            disabled={registerMutation.isPending}
          >
            {registerMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Account
          </Button>
        </form>
      </Form>
      
      <div className="relative flex items-center justify-center mt-6 mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-700"></div>
        </div>
        <div className="relative px-4 bg-dark-light">
          <span className="text-sm text-gray-400">Or register with</span>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-3">
        <button className="flex justify-center items-center py-2 px-4 border border-gray-700 rounded hover:bg-dark transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="20" height="20">
            <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
            <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
            <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
            <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
          </svg>
        </button>
        <button className="flex justify-center items-center py-2 px-4 border border-gray-700 rounded hover:bg-dark transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="20" height="20">
            <path fill="#039be5" d="M24 5A19 19 0 1 0 24 43A19 19 0 1 0 24 5Z"/>
            <path fill="#fff" d="M26.572,29.036h4.917l0.772-4.995h-5.69v-2.73c0-2.075,0.678-3.915,2.619-3.915h3.119v-4.359c-0.548-0.074-1.707-0.236-3.897-0.236c-4.573,0-7.254,2.415-7.254,7.917v3.323h-4.701v4.995h4.701v13.729C22.089,42.905,23.032,43,24,43c0.875,0,1.729-0.08,2.572-0.194V29.036z"/>
          </svg>
        </button>
        <button className="flex justify-center items-center py-2 px-4 border border-gray-700 rounded hover:bg-dark transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="20" height="20">
            <path fill="#fff" d="M41,24c0,9.4-7.6,17-17,17S7,33.4,7,24S14.6,7,24,7S41,14.6,41,24z"/>
            <path fill="#455a64" d="M21,41v-5.5c0-0.3,0.2-0.5,0.5-0.5s0.5,0.2,0.5,0.5V41h2v-6.5c0-0.3,0.2-0.5,0.5-0.5s0.5,0.2,0.5,0.5V41h2v-5.5c0-0.3,0.2-0.5,0.5-0.5s0.5,0.2,0.5,0.5V41h1.8c0.2-0.3,0.2-0.6,0.2-1v-6.5c0-0.8-0.7-1.5-1.5-1.5h-3.5c-0.8,0-1.5,0.7-1.5,1.5V40C23,40.4,23,40.7,23.2,41H21z M16.5,21.6c0-0.3,0-0.5,0.1-0.8l-5.9-1.2c-0.1,0.5-0.1,1-0.1,1.5c0,1.1,0.2,2.1,0.5,3.1l5.7-2.1C16.6,22.5,16.5,22.1,16.5,21.6z M25,15c1.8,0,3.4,0.8,4.5,2l4.5-3.5C32.1,10.8,28.8,9,25,9c-4.1,0-7.7,2-10,5.1l5.9,1.2C21.7,16.2,23.2,15,25,15z M40.5,22.4c0-0.4-0.1-0.7-0.1-1.1l-5.7,0.8c0,0.2,0,0.4,0,0.6c0,0.1,0,0.2,0,0.3l5.7,0.5C40.4,23.2,40.5,22.8,40.5,22.4z M29.5,21.7c0,0.8-0.1,1.6-0.4,2.3L35,26c0.9-1.1,1.5-2.5,1.8-4l-5.7-0.5C30.9,21.5,30.8,21.6,29.5,21.7z M33.2,27.1l-5.9-2c-0.8,1.2-2.1,2-3.7,2c-2.4,0-4.4-2-4.4-4.4S21.1,18.1,23.5,18.1c0.6,0,1.1,0.1,1.6,0.3l5.9-1.2c-1.1-2.2-3.4-3.7-6-3.7c-3.7,0-6.7,3-6.7,6.7s3,6.7,6.7,6.7C28.5,26.9,31.3,24.5,33.2,27.1z M35.8,13.4l-4.5,3.5c1.4,1.4,2.3,3.4,2.3,5.6c0,0.2,0,0.4,0,0.6l5.7-0.8c-0.2-2.1-0.9-4-1.9-5.7C36.8,15.4,36.3,14.4,35.8,13.4z M16.8,26.2L11.2,28c1.3,3,3.7,5.3,6.8,6.7v-7.2C17.3,27.2,17,26.7,16.8,26.2z"/>
          </svg>
        </button>
      </div>

      {/* Terms of Service Dialog */}
      <Dialog open={termsDialogOpen} onOpenChange={setTermsDialogOpen}>
        <DialogContent className="bg-dark border border-gray-700 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl text-gold">Terms of Service</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 text-gray-300">
            <h3 className="text-lg font-medium text-gold">1. Introduction</h3>
            <p>Welcome to our Christian devotional platform. By using our service, you agree to these Terms of Service. Please read them carefully.</p>
            
            <h3 className="text-lg font-medium text-gold">2. Using Our Service</h3>
            <p>You must follow any policies made available to you within the Service. You must not misuse our Service, including but not limited to engaging in illegal activities, spreading hate speech, harassing other users, or posting inappropriate content.</p>
            
            <h3 className="text-lg font-medium text-gold">3. Account Creation</h3>
            <p>To use certain features of our Service, you may need to create an account. You are responsible for the security of your account and for any activity that occurs through your account.</p>
            
            <h3 className="text-lg font-medium text-gold">4. Content Guidelines</h3>
            <p>Our platform focuses on spiritual growth and Christian values. All content must be respectful, supportive, and in line with Christian teachings. Content that contradicts these values may be removed.</p>
            
            <h3 className="text-lg font-medium text-gold">5. Community Standards</h3>
            <p>We expect all users to treat each other with respect and dignity. Harassment, bullying, or any form of abuse will not be tolerated and may result in account termination.</p>
            
            <h3 className="text-lg font-medium text-gold">6. Intellectual Property</h3>
            <p>The content you create and share remains yours, but you grant us a license to use it on our platform. We respect copyright laws and expect our users to do the same.</p>
            
            <h3 className="text-lg font-medium text-gold">7. Termination</h3>
            <p>We reserve the right to suspend or terminate accounts that violate our terms of service or community guidelines.</p>
            
            <h3 className="text-lg font-medium text-gold">8. Changes to Terms</h3>
            <p>We may modify these terms from time to time. We will notify users of significant changes.</p>
            
            <h3 className="text-lg font-medium text-gold">9. Governing Law</h3>
            <p>These terms are governed by the laws of our jurisdiction, without regard to its conflict of law principles.</p>
          </div>
          <Button 
            onClick={() => setTermsDialogOpen(false)}
            className="bg-gold text-dark hover:bg-amber-600 transition-colors mt-4"
          >
            I Understand
          </Button>
        </DialogContent>
      </Dialog>

      {/* Privacy Policy Dialog */}
      <Dialog open={privacyDialogOpen} onOpenChange={setPrivacyDialogOpen}>
        <DialogContent className="bg-dark border border-gray-700 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl text-gold">Privacy Policy</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 text-gray-300">
            <h3 className="text-lg font-medium text-gold">1. Information We Collect</h3>
            <p>We collect information you provide directly, such as your name, email address, profile information, and content you post. We also collect certain technical information about your usage patterns and device.</p>
            
            <h3 className="text-lg font-medium text-gold">2. How We Use Your Information</h3>
            <p>We use your information to provide, maintain, and improve our services, to communicate with you, and to ensure the security of our platform. We do not sell your personal information to third parties.</p>
            
            <h3 className="text-lg font-medium text-gold">3. Information Sharing</h3>
            <p>We may share your information in the following circumstances: with your consent, for legal reasons, or with service providers who help us operate our platform.</p>
            
            <h3 className="text-lg font-medium text-gold">4. Security</h3>
            <p>We implement reasonable security measures to protect your personal information. However, no method of transmission over the internet is 100% secure.</p>
            
            <h3 className="text-lg font-medium text-gold">5. Your Rights</h3>
            <p>Depending on your location, you may have rights regarding your personal information, such as the right to access, correct, or delete your data.</p>
            
            <h3 className="text-lg font-medium text-gold">6. Third-Party Links</h3>
            <p>Our service may contain links to third-party websites or services that are not owned or controlled by us. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party websites or services.</p>
            
            <h3 className="text-lg font-medium text-gold">7. Children's Privacy</h3>
            <p>Our service is not directed to children under the age of 13. If we learn that we have collected personal information from a child under 13, we will take steps to delete that information.</p>
            
            <h3 className="text-lg font-medium text-gold">8. Changes to Policy</h3>
            <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
            
            <h3 className="text-lg font-medium text-gold">9. Contact Us</h3>
            <p>If you have any questions about this Privacy Policy, please contact us through the platform or at the provided contact information.</p>
          </div>
          <Button 
            onClick={() => setPrivacyDialogOpen(false)}
            className="bg-gold text-dark hover:bg-amber-600 transition-colors mt-4"
          >
            I Understand
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
