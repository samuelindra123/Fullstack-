import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2, Star } from "lucide-react";
import { RegistrationStep4Data, registrationStep4Schema } from "@shared/schema";
import { useState } from "react";

interface Step4FeedbackProps {
  onSubmit: (data: RegistrationStep4Data) => void;
  onBack: () => void;
  defaultValues?: Partial<RegistrationStep4Data>;
  isPending?: boolean;
}

export default function Step4Feedback({ onSubmit: onNextSubmit, onBack, defaultValues, isPending = false }: Step4FeedbackProps) {
  const [hoveredRating, setHoveredRating] = useState<number | null>(null);
  
  const form = useForm<RegistrationStep4Data>({
    resolver: zodResolver(registrationStep4Schema),
    defaultValues: {
      appRating: defaultValues?.appRating || 0,
      feedback: defaultValues?.feedback || "",
    },
  });

  const watchedRating = form.watch('appRating');

  const handleStarClick = (rating: number) => {
    form.setValue('appRating', rating);
  };

  const onSubmit = (data: RegistrationStep4Data) => {
    onNextSubmit(data);
  };

  return (
    <div className="space-y-6 w-full max-w-md mx-auto">
      <div className="text-center">
        <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-1 mb-2">
          <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">4/4</span>
        </div>
        <h1 className="text-2xl font-bold">Feedback Anda</h1>
        <p className="text-muted-foreground mt-2">
          Bagikan pendapat Anda tentang pengalaman Anda dengan aplikasi kami
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="appRating"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Berikan Rating</FormLabel>
                <FormControl>
                  <div className="flex items-center justify-center gap-2 py-2">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        type="button"
                        className="focus:outline-none"
                        onClick={() => handleStarClick(rating)}
                        onMouseEnter={() => setHoveredRating(rating)}
                        onMouseLeave={() => setHoveredRating(null)}
                      >
                        <Star
                          className={`h-8 w-8 ${
                            (hoveredRating !== null ? rating <= hoveredRating : rating <= field.value)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-muted-foreground"
                          } transition-colors`}
                        />
                      </button>
                    ))}
                  </div>
                </FormControl>
                {watchedRating > 0 && (
                  <div className="text-center text-sm">
                    {watchedRating === 1 && "Sangat Buruk"}
                    {watchedRating === 2 && "Buruk"}
                    {watchedRating === 3 && "Cukup"}
                    {watchedRating === 4 && "Baik"}
                    {watchedRating === 5 && "Sangat Baik"}
                  </div>
                )}
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="feedback"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Feedback (Opsional)</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Berikan feedback Anda di sini..."
                    className="resize-none min-h-[100px]"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Feedback Anda akan membantu kami meningkatkan layanan
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex gap-3">
            <Button type="button" variant="outline" className="flex-1" onClick={onBack}>
              Kembali
            </Button>
            <Button type="submit" className="flex-1" disabled={isPending}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Menyelesaikan...
                </>
              ) : (
                "Selesaikan Pendaftaran"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}