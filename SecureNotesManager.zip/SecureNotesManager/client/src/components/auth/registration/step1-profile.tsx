import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { Camera, Loader2, UserCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { RegistrationStep1Data, registrationStep1Schema } from "@shared/schema";

interface Step1ProfileProps {
  onNext: (data: RegistrationStep1Data) => void;
  defaultValues?: Partial<RegistrationStep1Data>;
  isPending?: boolean;
}

export default function Step1Profile({ onNext, defaultValues, isPending = false }: Step1ProfileProps) {
  const { toast } = useToast();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const form = useForm<RegistrationStep1Data>({
    resolver: zodResolver(registrationStep1Schema),
    defaultValues: {
      channelUsername: defaultValues?.channelUsername || "",
      profilePicture: defaultValues?.profilePicture || "",
    },
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "Ukuran file terlalu besar",
          description: "Maksimal ukuran file adalah 5MB",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        setPreviewUrl(dataUrl);
        form.setValue("profilePicture", dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: RegistrationStep1Data) => {
    onNext(data);
  };

  return (
    <div className="space-y-6 w-full max-w-md mx-auto">
      <div className="text-center">
        <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-1 mb-2">
          <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">1/4</span>
        </div>
        <h1 className="text-2xl font-bold">Lengkapi Profil Anda</h1>
        <p className="text-muted-foreground mt-2">
          Unggah foto profil dan buat nama channel Anda
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="flex flex-col items-center justify-center gap-4">
            <Label htmlFor="picture" className="cursor-pointer relative block">
              <Avatar className="h-24 w-24 border-2 border-primary/50">
                <AvatarImage src={previewUrl || ""} alt="Profile picture preview" />
                <AvatarFallback className="bg-muted">
                  <UserCircle className="h-12 w-12 text-muted-foreground" />
                </AvatarFallback>
              </Avatar>
              <div className="absolute bottom-0 right-0 h-7 w-7 rounded-full bg-primary flex items-center justify-center">
                <Camera className="h-4 w-4 text-primary-foreground" />
              </div>
            </Label>
            <Input
              id="picture"
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />
            <p className="text-sm text-muted-foreground">Klik untuk mengunggah foto</p>
          </div>

          <FormField
            control={form.control}
            name="channelUsername"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nama Channel</FormLabel>
                <FormControl>
                  <Input placeholder="channel_anda" {...field} />
                </FormControl>
                <FormDescription>
                  Nama channel akan ditampilkan di profil Anda
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button type="submit" className="w-full" disabled={isPending}>
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Menyimpan...
              </>
            ) : (
              "Lanjutkan"
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}