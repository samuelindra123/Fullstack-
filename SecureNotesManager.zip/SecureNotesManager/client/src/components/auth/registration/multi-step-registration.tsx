import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import Step1Profile from "./step1-profile";
import Step2PersonalInfo from "./step2-personal-info";
import Step3Interests from "./step3-interests";
import Step4Feedback from "./step4-feedback";
import {
  RegistrationStep1Data,
  RegistrationStep2Data,
  RegistrationStep3Data,
  RegistrationStep4Data,
  InitialRegistrationData,
} from "@shared/schema";

interface MultiStepRegistrationProps {
  email: string;
  onComplete: () => void;
  initialUserData: InitialRegistrationData;
}

export default function MultiStepRegistration({
  email,
  onComplete,
  initialUserData,
}: MultiStepRegistrationProps) {
  const { completeRegistrationMutation } = useAuth();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  
  // Store form data for each step
  const [formData, setFormData] = useState<{
    step1: Partial<RegistrationStep1Data>;
    step2: Partial<RegistrationStep2Data>;
    step3: Partial<RegistrationStep3Data>;
    step4: Partial<RegistrationStep4Data>;
  }>({
    step1: {},
    step2: {},
    step3: {},
    step4: {},
  });

  // Handle step 1 submission
  const handleStep1 = (data: RegistrationStep1Data) => {
    setFormData((prev) => ({ ...prev, step1: data }));
    setCurrentStep(2);
  };

  // Handle step 2 submission
  const handleStep2 = (data: RegistrationStep2Data) => {
    setFormData((prev) => ({ ...prev, step2: data }));
    setCurrentStep(3);
  };

  // Handle step 3 submission
  const handleStep3 = (data: RegistrationStep3Data) => {
    setFormData((prev) => ({ ...prev, step3: data }));
    setCurrentStep(4);
  };

  // Handle step 4 submission (final step)
  const handleStep4 = (data: RegistrationStep4Data) => {
    setFormData((prev) => ({ ...prev, step4: data }));
    
    // Combine all form data and ensure dateOfBirth is a Date object and all required fields exist
    const completeRegistrationData = {
      ...initialUserData,
      ...formData.step3,
      ...data,
      isProfileComplete: true,
      // Make sure step1 data is valid
      channelUsername: formData.step1.channelUsername || `user_${Math.floor(Math.random() * 10000)}`,
      profilePicture: formData.step1.profilePicture,
      
      // Make sure step2 data is valid
      dateOfBirth: formData.step2.dateOfBirth 
        ? (typeof formData.step2.dateOfBirth === 'string' 
          ? new Date(formData.step2.dateOfBirth) 
          : formData.step2.dateOfBirth)
        : new Date(),
      gender: formData.step2.gender || 'prefer_not_to_say',
      
      // Make sure step3 data is valid
      interests: formData.step3.interests || [],
    };

    // Submit complete registration data
    completeRegistrationMutation.mutate(completeRegistrationData, {
      onSuccess: () => {
        toast({
          title: "Pendaftaran Berhasil",
          description: "Akun Anda telah berhasil terdaftar!",
        });
        onComplete();
      },
      onError: (error) => {
        toast({
          title: "Pendaftaran Gagal",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <div className="w-full">
      {currentStep === 1 && (
        <Step1Profile
          onNext={handleStep1}
          defaultValues={formData.step1}
          isPending={false}
        />
      )}

      {currentStep === 2 && (
        <Step2PersonalInfo
          onNext={handleStep2}
          onBack={() => setCurrentStep(1)}
          defaultValues={formData.step2}
          isPending={false}
        />
      )}

      {currentStep === 3 && (
        <Step3Interests
          onNext={handleStep3}
          onBack={() => setCurrentStep(2)}
          defaultValues={formData.step3}
          isPending={false}
        />
      )}

      {currentStep === 4 && (
        <Step4Feedback
          onSubmit={handleStep4}
          onBack={() => setCurrentStep(3)}
          defaultValues={formData.step4}
          isPending={completeRegistrationMutation.isPending}
        />
      )}
    </div>
  );
}