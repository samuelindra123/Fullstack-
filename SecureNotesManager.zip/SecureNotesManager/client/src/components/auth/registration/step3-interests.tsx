import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { CheckboxItem } from "@/components/ui/checkbox";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2 } from "lucide-react";
import { RegistrationStep3Data, registrationStep3Schema } from "@shared/schema";

interface Step3InterestsProps {
  onNext: (data: RegistrationStep3Data) => void;
  onBack: () => void;
  defaultValues?: Partial<RegistrationStep3Data>;
  isPending?: boolean;
}

const RELIGION_INTERESTS = [
  { id: "kristen", label: "Kristen" },
  { id: "katholik", label: "Katholik" },
  { id: "islam", label: "Islam" },
  { id: "buddha", label: "Buddha" },
  { id: "hindu", label: "Hindu" },
  { id: "others_religion", label: "Lainnya" },
];

const HOBBY_INTERESTS = [
  { id: "music", label: "Musik" },
  { id: "sports", label: "Olahraga" },
  { id: "technology", label: "Teknologi" },
  { id: "art", label: "Seni" },
  { id: "cooking", label: "Memasak" },
  { id: "reading", label: "Membaca" },
  { id: "travel", label: "Traveling" },
  { id: "photography", label: "Fotografi" },
  { id: "writing", label: "Menulis" },
  { id: "gardening", label: "Berkebun" },
  { id: "others_hobby", label: "Lainnya" },
];

export default function Step3Interests({ onNext, onBack, defaultValues, isPending = false }: Step3InterestsProps) {
  const form = useForm<RegistrationStep3Data>({
    resolver: zodResolver(registrationStep3Schema),
    defaultValues: {
      interests: defaultValues?.interests || [],
    },
  });

  const onSubmit = (data: RegistrationStep3Data) => {
    onNext(data);
  };

  return (
    <div className="space-y-6 w-full max-w-md mx-auto">
      <div className="text-center">
        <div className="inline-flex items-center justify-center rounded-full bg-primary/10 p-1 mb-2">
          <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">3/4</span>
        </div>
        <h1 className="text-2xl font-bold">Minat dan Preferensi</h1>
        <p className="text-muted-foreground mt-2">
          Pilih minat dan preferensi Anda untuk pengalaman yang lebih personal
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="interests"
            render={() => (
              <FormItem>
                <div className="mb-4">
                  <FormLabel className="text-base">Agama</FormLabel>
                  <FormDescription>
                    Pilih agama yang sesuai dengan keyakinan Anda
                  </FormDescription>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {RELIGION_INTERESTS.map((item) => (
                    <FormField
                      key={item.id}
                      control={form.control}
                      name="interests"
                      render={({ field }) => {
                        return (
                          <FormItem
                            key={item.id}
                            className="flex flex-row items-start space-x-3 space-y-0"
                          >
                            <FormControl>
                              <CheckboxItem
                                checked={field.value?.includes(item.id)}
                                onCheckedChange={(checked) => {
                                  return checked
                                    ? field.onChange([...field.value, item.id])
                                    : field.onChange(
                                        field.value?.filter(
                                          (value) => value !== item.id
                                        )
                                      );
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">
                              {item.label}
                            </FormLabel>
                          </FormItem>
                        );
                      }}
                    />
                  ))}
                </div>
                
                <div className="mb-4 mt-6">
                  <FormLabel className="text-base">Hobi & Minat</FormLabel>
                  <FormDescription>
                    Pilih hobi dan minat Anda
                  </FormDescription>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {HOBBY_INTERESTS.map((item) => (
                    <FormField
                      key={item.id}
                      control={form.control}
                      name="interests"
                      render={({ field }) => {
                        return (
                          <FormItem
                            key={item.id}
                            className="flex flex-row items-start space-x-3 space-y-0"
                          >
                            <FormControl>
                              <CheckboxItem
                                checked={field.value?.includes(item.id)}
                                onCheckedChange={(checked) => {
                                  return checked
                                    ? field.onChange([...field.value, item.id])
                                    : field.onChange(
                                        field.value?.filter(
                                          (value) => value !== item.id
                                        )
                                      );
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">
                              {item.label}
                            </FormLabel>
                          </FormItem>
                        );
                      }}
                    />
                  ))}
                </div>
                <FormMessage className="mt-2" />
              </FormItem>
            )}
          />

          <div className="flex gap-3">
            <Button type="button" variant="outline" className="flex-1" onClick={onBack}>
              Kembali
            </Button>
            <Button type="submit" className="flex-1" disabled={isPending}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Menyimpan...
                </>
              ) : (
                "Lanjutkan"
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}