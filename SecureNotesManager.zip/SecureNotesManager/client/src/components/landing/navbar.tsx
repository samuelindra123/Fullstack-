import { useState, useEffect } from "react";
import { useLocation } from "wouter";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [, navigate] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(prev => !prev);
  };

  const handleSignIn = () => {
    navigate("/auth");
  };

  const handleJoinNow = () => {
    navigate("/auth");
  };

  return (
    <nav className={`fixed w-full ${scrolled ? 'bg-black bg-opacity-90' : 'bg-transparent'} backdrop-blur-sm py-4 z-50 transition-colors duration-300`}>
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <a href="#" className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gold mr-2">
            <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
          </svg>
          <span className="font-serif text-xl text-gold">Spiritual Journey</span>
        </a>
        <div className="hidden md:flex space-x-8">
          <a href="#" className="font-medium hover:text-gold transition-colors">Home</a>
          <a href="#features" className="font-medium hover:text-gold transition-colors">Features</a>
          <a href="#about" className="font-medium hover:text-gold transition-colors">About</a>
          <a href="#testimonials" className="font-medium hover:text-gold transition-colors">Testimonials</a>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            className="hidden md:block py-2 px-4 rounded border border-gold text-gold hover:bg-gold hover:text-dark transition-colors"
            onClick={handleSignIn}
          >
            Sign In
          </button>
          <button 
            className="py-2 px-4 rounded bg-gold text-dark font-medium hover:bg-amber-600 transition-colors"
            onClick={handleJoinNow}
          >
            Join Now
          </button>
          <button 
            className="md:hidden text-xl"
            onClick={toggleMobileMenu}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="3" y1="12" x2="21" y2="12"/>
              <line x1="3" y1="6" x2="21" y2="6"/>
              <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>
        </div>
      </div>
      <div className={`md:hidden bg-gray-900 absolute w-full transition-transform duration-300 ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
          <a href="#" className="font-medium py-2 hover:text-gold transition-colors">Home</a>
          <a href="#features" className="font-medium py-2 hover:text-gold transition-colors">Features</a>
          <a href="#about" className="font-medium py-2 hover:text-gold transition-colors">About</a>
          <a href="#testimonials" className="font-medium py-2 hover:text-gold transition-colors">Testimonials</a>
          <a 
            href="#" 
            className="font-medium py-2 text-gold transition-colors"
            onClick={handleSignIn}
          >
            Sign In
          </a>
        </div>
      </div>
    </nav>
  );
}
