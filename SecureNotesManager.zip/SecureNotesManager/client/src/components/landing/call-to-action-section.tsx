import { useLocation } from "wouter";

export default function CallToActionSection() {
  const [, navigate] = useLocation();

  const handleCTAClick = () => {
    navigate("/auth");
  };

  const handleSignInClick = (e: React.MouseEvent) => {
    e.preventDefault();
    navigate("/auth");
  };

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 opacity-10 bg-cover bg-center" style={{
        backgroundImage: "linear-gradient(rgba(0,0,0,0.8), rgba(0,0,0,0.8))",
      }}>
        {/* Cross SVG background */}
        <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M50,0 L50,100 M0,50 L100,50" stroke="white" strokeWidth="0.5" />
        </svg>
      </div>
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="font-serif text-4xl md:text-5xl text-gold mb-6">Join Our Spiritual Community Today</h2>
          <p className="text-lg text-gray-300 mb-10">Connect with fellow believers, access daily devotionals, and grow in your faith through our supportive community.</p>
          <button 
            className="py-4 px-10 bg-gold text-dark text-xl font-medium rounded-lg hover:bg-amber-600 transform hover:scale-105 transition-all duration-300"
            onClick={handleCTAClick}
          >
            Begin Your Journey Now
          </button>
          <p className="mt-6 text-gray-400">
            Already a member? <a href="#" className="text-gold hover:underline" onClick={handleSignInClick}>Sign in here</a>
          </p>
        </div>
      </div>
    </section>
  );
}
