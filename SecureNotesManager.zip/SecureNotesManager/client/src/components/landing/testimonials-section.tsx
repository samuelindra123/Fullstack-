import { useState, useEffect, useRef } from "react";

export default function TestimonialsSection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const testimonials = [
    {
      name: "Sarah J.",
      duration: "Member for 2 years",
      text: "This platform has transformed my daily devotional practice. The reflections are deep and meaningful, and the community has become like family.",
      image: "https://ui-avatars.com/api/?name=Sarah+J&background=random"
    },
    {
      name: "Michael T.",
      duration: "Member for 1 year",
      text: "The inspirational videos have helped me through some dark times. I feel more connected to my faith than ever before through this amazing community.",
      image: "https://ui-avatars.com/api/?name=Michael+T&background=random"
    },
    {
      name: "Rebecca M.",
      duration: "Member for 3 years",
      text: "The prayer resources have enriched my spiritual practice and helped me find words when I had none. I'm grateful for this spiritual oasis.",
      image: "https://ui-avatars.com/api/?name=Rebecca+M&background=random"
    }
  ];

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const prevSlide = () => {
    setCurrentSlide((current) => (current === 0 ? testimonials.length - 1 : current - 1));
  };

  const nextSlide = () => {
    setCurrentSlide((current) => (current === testimonials.length - 1 ? 0 : current + 1));
  };

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.style.transform = `translateX(-${currentSlide * 100}%)`;
    }
  }, [currentSlide]);

  return (
    <section id="testimonials" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="font-serif text-4xl text-gold text-center mb-16">Member Testimonials</h2>
        
        <div className="testimonial-slider relative max-w-4xl mx-auto">
          <div className="overflow-hidden">
            <div 
              ref={containerRef}
              className="flex transition-transform duration-500" 
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="min-w-full px-4">
                  <div className="bg-black p-8 rounded-lg">
                    <div className="flex items-center mb-6">
                      <div className="w-16 h-16 rounded-full overflow-hidden mr-4">
                        <img 
                          src={testimonial.image}
                          alt={testimonial.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-serif text-xl text-gold">{testimonial.name}</h4>
                        <p className="text-gray-400">{testimonial.duration}</p>
                      </div>
                    </div>
                    <p className="text-lg italic text-gray-300">{testimonial.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <button 
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 bg-gold text-black w-10 h-10 rounded-full flex items-center justify-center"
            onClick={prevSlide}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m15 18-6-6 6-6"/>
            </svg>
          </button>
          <button 
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 bg-gold text-black w-10 h-10 rounded-full flex items-center justify-center"
            onClick={nextSlide}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </button>
          
          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <button 
                key={index}
                className={`w-3 h-3 rounded-full ${currentSlide === index ? 'bg-gold' : 'bg-gray-600'}`}
                onClick={() => goToSlide(index)}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
