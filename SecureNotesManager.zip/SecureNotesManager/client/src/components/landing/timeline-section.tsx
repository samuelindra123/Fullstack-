export default function TimelineSection() {
  const timelineEvents = [
    {
      title: "Awakening",
      description: "The first steps of faith begin with a spiritual awakening, where one encounters the presence of God and the message of salvation through Christ.",
      quote: "\"I once was lost but now am found, was blind, but now I see.\" - Amazing Grace"
    },
    {
      title: "Discipleship",
      description: "Growing in faith through regular study of scripture, prayer, and fellowship with other believers to become more Christ-like.",
      quote: "\"Therefore go and make disciples of all nations...\" - Matthew 28:19"
    },
    {
      title: "Service",
      description: "Putting faith into action by serving others with love and compassion, following Christ's example as a servant leader.",
      quote: "\"For even the Son of Man did not come to be served, but to serve...\" - Mark 10:45"
    },
    {
      title: "Maturity",
      description: "Reaching spiritual maturity by developing the fruit of the Spirit and becoming a mentor to others on their faith journey.",
      quote: "\"But the fruit of the Spirit is love, joy, peace, forbearance, kindness...\" - Galatians 5:22-23"
    }
  ];

  return (
    <section id="about" className="py-20 bg-black">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="font-serif text-4xl text-gold text-center mb-16">The Christian Journey</h2>
        
        <div className="max-w-3xl mx-auto relative">
          <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-gold"></div>
          
          {timelineEvents.map((event, index) => (
            <div key={index} className="pl-12 pb-16 relative" style={{ position: 'relative' }}>
              {/* Timeline dot */}
              <div className="absolute left-[-9px] top-0 w-[18px] h-[18px] rounded-full bg-gold z-10"></div>
              
              <h3 className="font-serif text-2xl text-gold mb-3">{event.title}</h3>
              <p className="text-lg text-gray-300 mb-4">{event.description}</p>
              <div className="bg-gray-800 p-4 rounded-lg">
                <p className="italic text-gray-400">{event.quote}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
