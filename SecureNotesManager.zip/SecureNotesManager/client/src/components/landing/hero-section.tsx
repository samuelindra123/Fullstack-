import { useLocation } from "wouter";

export default function HeroSection() {
  const [, navigate] = useLocation();

  const handleCTAClick = () => {
    navigate("/auth");
  };

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-b from-black to-gray-900">
      <div className="absolute inset-0 opacity-10">
        {/* Cross background */}
        <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M50,0 L50,100 M0,50 L100,50" stroke="white" strokeWidth="0.5" />
        </svg>
      </div>
      <div className="container mx-auto px-4 md:px-6 py-20 relative z-10">
        <div className="max-w-3xl">
          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold text-gold mb-6 animate-fadeIn">
            Find Peace in Christian Reflection
          </h1>
          <p className="text-lg md:text-xl text-gray-200 mb-8 animate-slideUp">
            Daily devotionals, inspirational videos, and prayers to deepen your spiritual journey. Join our community and grow in faith together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              className="py-3 px-8 bg-gold text-dark text-lg font-medium rounded hover:bg-amber-600 transform hover:scale-105 transition-all duration-300"
              onClick={handleCTAClick}
            >
              Begin Your Spiritual Journey
            </button>
            <button className="py-3 px-8 border border-gold text-gold text-lg font-medium rounded hover:bg-gold hover:text-dark transition-colors duration-300">
              Learn More
            </button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-8 w-full text-center">
        <a href="#features" className="text-gold animate-bounce inline-block">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down">
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </a>
      </div>
    </section>
  );
}
